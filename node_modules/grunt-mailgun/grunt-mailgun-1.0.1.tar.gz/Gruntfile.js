/*
 * grunt-mailgun
 * https://github.com/markhuge/grunt-mailgun
 *
 * Copyright (c) 2013 Mark Wilkerson
 * Licensed under the MIT license.
 */

'use strict';

module.exports = function(grunt) {
  grunt.loadTasks('tasks');
};
